# EUDR Visual Checker API

API FastAPI pour comparer imagerie Sentinel‑2 **avant 2021** vs **récente** sur une zone GeoJSON.

## Lancer en local
```bash
cp .env.example .env
docker compose up --build
```

## Déploiement Render
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)
